package locadora;

public interface Incremento {

	int incrementoID();
	
}
